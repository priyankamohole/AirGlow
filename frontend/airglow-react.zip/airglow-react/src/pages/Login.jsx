import { useNavigate } from 'react-router-dom'
import { LogoIcon } from '../components/icons.jsx'

export default function Login() {
  const navigate = useNavigate()

  function handleSubmit(e) {
    e.preventDefault()
    navigate('/app/dashboard')
  }

  return (
    <div className="login-page">
      <div className="login-brand">
        <div className="brand-logo">
          <LogoIcon size={26} />
          AirGlow
        </div>
        <h1 className="brand-headline">Welcome to AirGlow</h1>
        <p className="brand-sub">Data pipeline orchestrator</p>
        <div className="etl-graphic">
          <div className="etl-box extract">Extract</div>
          <div className="etl-arrow">&rarr;</div>
          <div className="etl-box transform">Transform</div>
          <div className="etl-arrow">&rarr;</div>
          <div className="etl-box load">Load</div>
        </div>
      </div>

      <div className="login-form-wrap">
        <form className="login-form" onSubmit={handleSubmit}>
          <h2>Sign in to your account</h2>
          <div className="field">
            <label htmlFor="email">Email address</label>
            <input id="email" type="email" placeholder="name@company.com" required />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input id="password" type="password" placeholder="••••••••••" required />
          </div>
          <div className="row-between">
            <label><input type="checkbox" defaultChecked style={{ width: 'auto' }} /> Remember me</label>
            <a href="#forgot">Forgot password?</a>
          </div>
          <button type="submit" className="btn btn-primary btn-block">Sign in</button>
          <div className="divider-text">or continue with</div>
          <div className="oauth-row">
            <button type="button" className="btn">Google</button>
            <button type="button" className="btn">GitHub</button>
          </div>
          <p className="signup-line">Don't have an account? <a href="#signup">Sign up</a></p>
        </form>
      </div>
    </div>
  )
}
